function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5XjtO9ryE9O":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

